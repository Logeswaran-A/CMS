﻿using CMS.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Repository
{
    public interface IUserRepo
    {
        Task<List<User>> GetAllUser();

        Task<User> GetUserById(int UserId);

        Task<int> AddUser(User user);

        Task<int> DeleteUser(int UserId);

        Task<int> UpdateUser(int UserId,User user);

        Task<User> Login(string Emailid, string password);
    }
}
