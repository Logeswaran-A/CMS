﻿using CMS.Database;
using CMS.Model;
using CMS.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Service
{
    public class UserRepo : IUserRepo
    {
        private readonly CMSContext cMSContext;

        public UserRepo(CMSContext cMSContext)
        {
            this.cMSContext = cMSContext;
        }
        public async Task<List<User>> GetAllUser()
        {
            var ar = await cMSContext.Users.ToListAsync();
            return ar;
        }
        public async Task<User> GetUserById(int userId)
        {
            var ar = await cMSContext.Users.Where(x => x.UserId == userId).FirstOrDefaultAsync();
            return ar;
        }
        public async Task<int> AddUser(User user)
        {
            cMSContext.Users.Add(new User { MemberName = user.MemberName, Password = user.Password, ConfirmPassword = user.ConfirmPassword, Address = user.Address, State = user.State, Country = user.Country, Email = user.Email,Number=user.Number, Dob = user.Dob, Plan = user.Plan });
            await cMSContext.SaveChangesAsync();
            return user.UserId;
        }

        public async Task<int> DeleteUser(int userId)
        {
            var ar = await cMSContext.Users.Where(x => x.UserId == userId).FirstOrDefaultAsync();
            if(ar!=null)
            {
                cMSContext.Users.Remove(ar);
                await cMSContext.SaveChangesAsync();
            }
            return userId;
        }

        public async Task<int> UpdateUser(int userId,User user)
        {
            var ar = await cMSContext.Users.Where(x => x.UserId == userId).FirstOrDefaultAsync();
            if(ar!=null)
            {
                ar.MemberName = user.MemberName;
                ar.Address = user.Address;
                ar.State = user.State;
                ar.Country = user.Country;
                ar.Email = user.Email;
                ar.Number = user.Number;
                ar.Dob = user.Dob;
                ar.Plan = user.Plan;
                await cMSContext.SaveChangesAsync();
            }
            return userId;
        }



        public async Task<User> Login(string EmailId, string password)
        {
            var ar = await cMSContext.Users.Where(x => x.Email == EmailId && x.Password == password).FirstOrDefaultAsync();
            if(ar!=null)
            {
                return ar;
            }
            else
            {
                return null;
            }
           
        }

        
    }
}
