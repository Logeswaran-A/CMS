﻿using CMS.Database;
using CMS.Model;
using CMS.Repository;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Service
{
    public class AdminRepo : IAdminRepo
    {
        private readonly CMSContext cMSContext;

        public AdminRepo(CMSContext cMSContext)
        {
            this.cMSContext = cMSContext;
        }
        public async Task<Admin> Login(string Emailid, string password)
        {
            var ar = await cMSContext.Admins.Where(x => x.AdminEmail == Emailid && x.AdminPassword == password).FirstOrDefaultAsync();
            if (ar != null)
            {
                return ar;
            }
            else
            {
                return null;
            }
        }
    }
}
