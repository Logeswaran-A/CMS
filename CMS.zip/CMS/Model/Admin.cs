﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Model
{
    public class Admin
    {
        [Key]
        [Required]
        public int AdminId { get; set; }

        [Required]
        public string AdminName { get; set; }

        [Required]
        [DataType(DataType.Password)]
        public string AdminPassword { get; set; }

        [Required]
        [DataType(DataType.EmailAddress)]
        public string AdminEmail { get; set; }
    }
}
