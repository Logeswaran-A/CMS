﻿using CMS.Model;
using CMS.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly IUserRepo userRepo;

        public UserController(IUserRepo userRepo)
        {
            this.userRepo = userRepo;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUser()
        {
            var users = await userRepo.GetAllUser();
            return Ok(users);
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> SearchById(int id)
        {
            var users = await userRepo.GetUserById(id);
            return Ok(users);
        }

        [HttpPost]
        public async Task<IActionResult> Add(User user)
        {
            var users = await userRepo.AddUser(new User { MemberName = user.MemberName, Password = user.Password, ConfirmPassword = user.ConfirmPassword, Address = user.Address, State = user.State, Country = user.Country, Email = user.Email, Dob = user.Dob, Number = user.Number, Plan = user.Plan });
            return Ok(users);
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var users = await userRepo.DeleteUser(id);
            return Ok(users);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id,User user)
        {
            var users = await userRepo.UpdateUser(id, user);
            return Ok(users);
        }

        [HttpGet("Login")]
        public async Task<IActionResult> Loginportal(string email,string password)
        {
            var users = await userRepo.Login(email, password);
            if(users!=null)
            {
                return Ok(users);
            }
            else
            {
                return null;
            }
        }
    }
}
