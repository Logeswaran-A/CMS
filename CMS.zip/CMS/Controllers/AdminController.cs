﻿using CMS.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace CMS.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {

        private readonly IAdminRepo adminRepo;

        public AdminController(IAdminRepo adminRepo)
        {
            this.adminRepo = adminRepo;
        }
        [HttpGet("Login")]
        public async Task<IActionResult> Loginportal(string email, string password)
        {
            var admins = await adminRepo.Login(email, password);
            if (admins != null)
            {
                return Ok(admins);
            }
            else
            {
                return null;
            }
        }
    }
}
